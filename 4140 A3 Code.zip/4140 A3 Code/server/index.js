const express = require('express');
const app = express();
const cors = require('cors');
const port = 3001;
const mysql = require('mysql');;
const bodyParser = require('body-parser');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Pass@123',
    database: 'A3'
});

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

// GET details about parts excluding the QoH
app.get('/api/listParts', (req, res) => {
    const sqlGetX = "SELECT partName519 FROM `X-parts519`;"
    const sqlGetY = "SELECT partName519 FROM `Y-parts519`;"
    var resArray = [];
    db.query(sqlGetX, (err, result) => {
        for(obj in result){
            resArray.push(result[obj].partName519);
        }

        db.query(sqlGetY, (err, result) => {
            for(obj in result){
                if(!resArray.includes(result[obj].partName519)){
                    resArray.push(result[obj].partName519);
                }
            }
            res.send(resArray);
        });
    });
});

// POST a new PO into the Z-table
app.post('/api/insertPo', async (req, res) => {
    const poNo = req.body.poNo;
    const lineNo = req.body.lineNo;
    const clientId = req.body.clientId;
    const poDate = req.body.poDate;
    const poStatus = req.body.poStatus;
    const cart = req.body.cart;

    var partAvailableFlag = Array(cart.length).fill(0); // this variable will tell us if all the parts can be provided by the 2 companies X & Y 

    const sqlGetX = "SELECT * FROM `X-parts519`;"
    const sqlGetY = "SELECT * FROM `Y-parts519`;"

    let xPo = false;
    let yPo = false;

    db.query(sqlGetX, (err, result) => {
        let x = 0;
        for(obj in result){
            // resArray.push(result[obj].partName519);
            while(x < cart.length){
                if(result[obj].partName519 === cart[x].partName && result[obj].qoh519 >= cart[x].qty){
                    partAvailableFlag[x] = {
                        flag: 'X',
                        partNo: result[obj].partNo519,
                        price: result[obj].currentPrice519
                    };
                    xPo = true;
                }
                x++;
            } 
        }


        db.query(sqlGetY, (err, result) => {
            let x = 0;
            for(obj in result){
                while(x < cart.length){
                    if(partAvailableFlag[x] === 0 && result[obj].partName519 === cart[x].partName && result[obj].qoh519 >= cart[x].qty){
                        partAvailableFlag[x] = {
                            flag: 'Y',
                            partNo: result[obj].partNo519,
                            price: result[obj].currentPrice519
                        };
                        yPo = true;
                    }
                    x++;
                } 
            }

            if(!partAvailableFlag.includes(0)){      
                //inserting PO into table Z
                const sqlInsertZ = "INSERT INTO `Z-pos519` (poNo519, clientCompID519, dateOfPO519, status519) VALUES (?,?,?,?)";
                db.query(sqlInsertZ, [poNo, clientId, poDate, poStatus], (err, result) => {
                    if(err == null){
                        res.send(true);
                    }        
                });
                
        
                //inserting lines in table Z
                for(var i=0; i<partAvailableFlag.length; i++){
                    console.log(partAvailableFlag[i]);
                    const sqlInsertZLine = "INSERT INTO `Z-lines519` (poNo519, lineNo519, partNo519, qty519, priceOrdered519, compOrdered519) VALUES (?,?,?,?,?,?)";
                    db.query(sqlInsertZLine, [poNo, lineNo, partAvailableFlag[i].partNo, cart[i].qty, partAvailableFlag[i].price, partAvailableFlag[i].flag], (err, result) => {
                        if(err == null){
                            res.send(true);
                        }
                        else{
                            console.log(err);
                        }
                    });
                }
        
                //inserting POs into tables X & Y, depending on whether we use parts from that table or not
                if(xPo){
                    const sqlInsertX = "INSERT INTO `X-pos519` (poNo519, clientCompID519, dateOfPO519, status519) VALUES (?,?,?,?)";
                    db.query(sqlInsertX, [poNo, clientId, poDate, poStatus], (err, result) => {
                        if(err == null){
                            res.send(true);
                        }
                    });
                }
    
                if(yPo){
                    const sqlInsertY = "INSERT INTO `Y-pos519` (poNo519, clientCompID519, dateOfPO519, status519) VALUES (?,?,?,?)";
                    db.query(sqlInsertY, [poNo, clientId, poDate, poStatus], (err, result) => {
                        if(err == null){
                            res.send(true);
                        }
                    });
                }
            }
            else{
                //cannot insert PO, the part entered is not available in requested quantity
            }


        });
        
    });
});

app.listen(port, () => {
    console.log('listening on port ' + port);
});
