import React, {useState, useEffect} from 'react';
import './App.css';
import Axios from 'axios';

function App() {

  const [listParts, setListParts] = useState(false);

  const [submitClientId, setSubmitClientId] = useState('');
  const [submitDate, setSubmitDate] = useState('');
  const [submitPoStatus, setSubmitPoStatus] = useState('');

  const [cartPartName, setCartPartName] = useState('');
  const [cartQty, setCartQty] = useState(0);
  const [cart, setCart] = useState([]);

  const [res1, setRes1] = useState("");
  const [submittedPo, setSubmittedPo] = useState(false);

  const submitForm = async (e) => {
    e.preventDefault();
    console.log(listParts)
    //if List Parts checkbox is checked: List all the parts without the QoH
    if(listParts){
      await Axios.get("http://localhost:3001/api/listParts")
      .then((response) => {
        setRes1("LIST OF PARTS: " + JSON.stringify(response.data));
      })
    }

    //submit a PO
    if(submitClientId !== '' && submitDate !== '' && submitPoStatus !== '' && cart.length > 0){
      await Axios.post("http://localhost:3001/api/insertPo", {
        poNo: Math.random().toString(36).slice(2), 
        lineNo: Math.random().toString(36).slice(2),
        clientId: submitClientId, 
        poDate: submitDate, 
        poStatus: submitPoStatus,
        cart: cart,
      })
      .then((response) => {
        setSubmittedPo(response);
      });
    }
    if(submittedPo){alert("Successfully submitted PO");}
    else{alert("Error submitting PO, please check the values and try again");}
  };

  const addToCart = (e) => {
    e.preventDefault();
    console.log("Clicked add to cart!");
    if(cartPartName !== "" && cartQty !== ""){
      cart.push({
        partName: cartPartName,
        qty: cartQty
      });
    }

    let cartItems = "";
    cart.map(item => (cartItems += "\n" + item.partName + ": " + item.qty));

    alert(cartPartName + ": " + cartQty + " Successfully Added to the cart\n\nCart contains:" + cartItems);
  }

  return (
    <div className="App">
      <h1>CSCI 4140 Assignment3</h1>
      <br /><br /><br /><br />
      <form className="form">
        <label className="formLabel">List Parts for sale</label>
        <input type="checkbox" id="getParts" name="getParts" onChange={(e) => {
          setListParts(e.target.checked);
        }}/>

        <br /><br /><hr />

        <p className="formLabel">Submit a PO:</p>
        <label>ClientCompID: </label>
        <input type="text" id="clientCompID" name="clientCompID" onChange={(e) => {
          setSubmitClientId(e.target.value);
        }}/>
        <br/><br/>
        <label>Date: </label>
        <input type="date" id="dateOfPO" name="dateOfPO" onChange={(e) => {
          setSubmitDate(e.target.value);
        }}/>
        <br/><br/>
        <label>Status: </label><br/>
          <input type="radio" id="status1" name="poStatus" value="processing" onChange={(e) => {
          setSubmitPoStatus(e.target.value);
        }}/>
          <label htmlFor="status1">Processing</label><br/>
          <input type="radio" id="status2" name="poStatus" value="in-progress" onChange={(e) => {
          setSubmitPoStatus(e.target.value);
        }}/>
          <label htmlFor="status2">In-Progress</label><br/>
        <br /><br />
        <label>Part Name: </label>
        <input type="text" id="partName" name="partName" onChange={(e) => {
          setCartPartName(e.target.value);
        }}/><br/><br/>
        <label>Quantity: </label>
        <input type="number" id="qty" name="qty" onChange={(e) => {
          setCartQty(e.target.value);
        }}/><br/><br/>
        <button onClick={addToCart}>ADD</button>
        <br/><br/>
        <hr />
        <button onClick={submitForm}>SUBMIT</button>    
      </form>   
      <div>
        <br /><br />
        {res1}
      </div>  
    </div>
  );
}

export default App;
